import { useContext } from "react"
import { ThemeContext } from "../../contexts/Theme"

export const ThemeButton = ({ children, onClick }) => {
    const { theme } = useContext(ThemeContext)
    return (
        <button onClick={onClick}>children</button>
    )
}