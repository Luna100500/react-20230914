export const Review = ({ review }) => {

    return (
        <div>
            {review.user}: {review.text}
        </div>
    )
}
